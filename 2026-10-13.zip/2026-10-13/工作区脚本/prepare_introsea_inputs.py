"""Prepare the verified introSea renderer's inputs from original unpacked YC files.

This is a scene-specific preparation script, not a universal YC decoder.
It never executes the game or writes to the game installation.
Use --work-root to validate preparation in a separate directory.
"""
from pathlib import Path
import argparse
import csv
import hashlib
import json
import math
import struct


WORKSPACE = Path(__file__).resolve().parent.parent
ASSET_ROOT = WORKSPACE / 'outputs/Mina the Hollower map assets/by-package'


def u32(b, o):
    return struct.unpack_from('<I', b, o)[0]


def i32(b, o):
    return struct.unpack_from('<i', b, o)[0]


def relative_qword(b, o):
    """The signed displacement occupies the HIGH word, relative to the LOW word."""
    return o + i32(b, o + 4)


def vector(b, o):
    encoded_count = u32(b, o + 4)
    if encoded_count % 4:
        raise ValueError(f'Unaligned encoded count at {o:#x}')
    return encoded_count // 4, relative_qword(b, o + 8)


def game_string(b, o):
    length = u32(b, o + 4)
    start = relative_qword(b, o + 8)
    if length == 0:
        return ''
    if not 0 <= start <= start + length <= len(b):
        raise ValueError(f'String outside file at {o:#x}')
    return b[start:start + length].split(b'\0')[0].decode('ascii')


def wflz(b, marker):
    if b[marker:marker + 4] != b'WFLZ':
        raise ValueError(f'Missing WFLZ at {marker:#x}')
    compressed, expected = struct.unpack_from('<II', b, marker + 4)
    cursor = marker + 12  # First token starts here, not after a skipped 16-byte header.
    output = bytearray()
    while cursor + 4 <= len(b):
        distance, length, literals = struct.unpack_from('<HBB', b, cursor)
        cursor += 4
        if not length and not literals:
            break
        if length:
            if not 0 < distance <= len(output):
                raise ValueError(f'Invalid back-reference at {cursor - 4:#x}')
            # This loop intentionally permits an overlapping back-reference.
            for _ in range(length + 4):
                output.append(output[-distance])
        if cursor + literals > len(b):
            raise ValueError('Literal run outside source')
        output.extend(b[cursor:cursor + literals])
        cursor += literals
        if len(output) > expected:
            raise ValueError('Decompression exceeded declared size')
    if len(output) != expected:
        raise ValueError(f'Decompressed {len(output)}, expected {expected}')
    return compressed, bytes(output)


def ascii_property_value(b, property_offset):
    # The property value pointer qword is at +0x10 in this 24-byte record.
    start = relative_qword(b, property_offset + 16)
    if not 0 <= start < len(b):
        return None
    value = b[start:start + 150].split(b'\0')[0]
    if value and all(32 <= v <= 126 for v in value):
        return value.decode('ascii')
    return None


def write_json(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf-8')


def write_csv(path, rows):
    with path.open('w', newline='', encoding='utf-8-sig') as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--map', type=Path, default=ASSET_ROOT / 'level_introSea.pak/levels/extra/introSea.tlb.yc')
    ap.add_argument('--work-root', type=Path, default=WORKSPACE / 'work')
    args = ap.parse_args()
    b = args.map.read_bytes()
    if b[:4] != b'YCD\0':
        raise ValueError('Expected YCD resource')
    root = struct.unpack_from('<Q', b, 8)[0]
    nlayers, layer_base = vector(b, root + 0x38)
    ninfo, info_base = vector(b, root + 0x78)
    ntextures, texture_base = vector(b, root + 0x88)
    nentities, entity_base = vector(b, root + 0x48)
    # Deliberate admission boundary: this tool documents the proven introSea case.
    assert (nlayers, ninfo, ntextures, nentities) == (26, 669, 1, 2613)
    assert (layer_base, info_base, texture_base, entity_base) == (0x238, 0x63324, 0x642d8, 0x2060)
    layers_out = args.work_root / 'introSea_layers_verified'
    streams_out = args.work_root / 'introSea_streams'
    metadata_out = args.work_root / 'introSea_corrected'
    for folder in (layers_out, streams_out, metadata_out):
        folder.mkdir(parents=True, exist_ok=True)

    layers, placements = [], []
    for index in range(nlayers):
        obj = layer_base + index * 0xa8
        name = game_string(b, obj + 0x10)
        width, height = struct.unpack_from('<II', b, obj + 0x80)
        position = list(struct.unpack_from('<ff', b, obj + 0x68))
        marker = relative_qword(b, obj + 0xa0)
        compressed, raw = wflz(b, marker)
        assert len(raw) % 512 == 0
        chunk_slots, chunk_table = vector(b, obj + 0x50)
        cols, rows = math.ceil(width / 16), math.ceil(height / 16)
        assert chunk_slots == cols * rows
        starts = struct.unpack_from('<' + 'I' * chunk_slots, b, chunk_table)
        used = []
        for slot, start in enumerate(starts):
            if start == 0xffffffff:
                continue
            assert start % 256 == 0 and start // 256 < len(raw) // 512
            used.append(start)
            placements.append({
                'layer_index': index, 'layer_name': name, 'grid_slot': slot,
                'chunk_x': slot % cols, 'chunk_y': slot // cols,
                'tile_data_chunk_index': start // 256, 'tile_data_cell_offset': start,
                'serialized_chunk_table_offset': hex(chunk_table),
            })
        assert len(used) == len(set(used)) == len(raw) // 512
        decoded = layers_out / f'{index:02d}_{name}.bin'
        decoded.write_bytes(raw)
        layers.append({
            'layer_index': index, 'layer_name': name,
            'serialized_layer_record_offset': hex(obj),
            'legacy_shifted_record_offset': hex(obj + 12),
            'm_tileData_reference_offset': hex(obj + 0xa4),
            'wflz_marker_offset': hex(marker), 'compressed_bytes': compressed,
            'decoded_bytes': len(raw), 'decoded_u16_count': len(raw) // 2,
            'inferred_16x16_chunk_count': len(raw) // 512,
            'layer_dims_tiles': [width, height], 'position_world': position,
            'depth': struct.unpack_from('<f', b, obj + 0x8c)[0],
            'decoded_file': str(decoded.resolve()),
        })
    assert len(placements) == 221
    write_csv(layers_out / 'layer_stream_index.csv', layers)
    write_csv(layers_out / 'chunk_placement.csv', placements)
    write_json(layers_out / 'layer_stream_index.json', layers)
    write_json(layers_out / 'chunk_placement.json', placements)

    texture_marker = relative_qword(b, texture_base + 0x20)
    _, texture_raw = wflz(b, texture_marker)
    tw, th, tile_w, tile_h = struct.unpack_from('<4I', b, texture_base)
    assert (tw, th, tile_w, tile_h) == (2048, 16, 8, 8)
    assert len(texture_raw) == tw * th == 32768
    texture_file = streams_out / f'26_{texture_marker:06x}_{len(texture_raw):06x}.bin'
    texture_file.write_bytes(texture_raw)

    scenery, reference_entities = [], []
    for index in range(nentities):
        obj = entity_base + index * 88
        prop_count, prop_base = vector(b, obj)
        assert 0 <= prop_count < 40 and 0 <= prop_base + prop_count * 24 <= len(b)
        strings = [value for i in range(prop_count)
                   if (value := ascii_property_value(b, prop_base + i * 24)) is not None]
        position = list(struct.unpack_from('<ff', b, obj + 16))
        asset = next((s for s in strings if 'animTiles/' in s and s.endswith('.anb.yc')), None)
        if asset:
            scenery.append({
                'index': index, 'offset': hex(obj), 'position': position,
                'scale': list(struct.unpack_from('<ff', b, obj + 24)),
                'tail': list(struct.unpack_from('<8I', b, obj + 56)),
                'asset': asset, 'strings': strings,
            })
        if any('helm.anb' in s or 'mast.anb' in s or 'MainAreaSceneCam' in s for s in strings):
            reference_entities.append({
                'entity_index': index, 'record_offset': hex(obj),
                'props_offset': hex(prop_base), 'position': position, 'props_strings': strings,
            })
    write_json(metadata_out / 'animated_scenery_entities.json', scenery)
    write_json(metadata_out / 'scenery_entities.json', reference_entities)
    write_json(metadata_out / 'preparation_manifest.json', {
        'map': str(args.map.resolve()), 'map_sha256': hashlib.sha256(b).hexdigest(),
        'root': hex(root), 'layers': nlayers, 'chunk_placements': len(placements),
        'tileInfo_count': ninfo, 'tileInfo_base': hex(info_base),
        'entity_count': nentities, 'animated_scenery_count': len(scenery),
        'texture_file': str(texture_file.resolve()),
        'texture_sha256': hashlib.sha256(texture_raw).hexdigest(),
        'limits': 'introSea only; property values are selected ASCII references, not a complete property decoder',
    })
    print(f'Prepared {nlayers} layers, {len(placements)} chunks, {ninfo} tileInfo entries, '
          f'{nentities} entities, {len(scenery)} animated scenery entities')
    print(f'Output: {args.work_root.resolve()}')


if __name__ == '__main__':
    main()
