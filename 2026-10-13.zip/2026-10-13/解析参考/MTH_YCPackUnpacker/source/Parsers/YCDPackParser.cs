﻿using MTH_YCPackUnpacker.Structures;
using MTH_YCPackUnpacker.Utils;

namespace MTH_YCPackUnpacker.Parsers
{
    public class FileEntryPack
    {
        public int Offset { get; set; }
        public int Length { get; set; }
        public string Name { get; set; }
        public long CurretnEntryOffset { get; set; }
    }

    public class YCDPackParser
    {
        public List<FileEntryPack> FileEntries { get; private set; } = new List<FileEntryPack>();

        private string currentFilePath;

        public YCDPackParser() { }

        public void Parse(string filePath)
        {
            currentFilePath = filePath;
            FileEntries.Clear();

            using (var fs = new FileStream(filePath, FileMode.Open, FileAccess.Read))
            using (var br = new BinaryReader(fs))
            {
                var header = br.ReadStruct<YCDHeader>();

                fs.Seek(header.ContentOffset, SeekOrigin.Begin);

                var tableDescriptor = ReadTableDescriptor(br);

                int filesCount = (int)tableDescriptor.FilesCount;
              //  Debug.WriteLine($"Found {filesCount} file entries");

                fs.Seek(tableDescriptor.FilesTablePointer, SeekOrigin.Begin);

                for (int i = 0; i < filesCount; i++)
                {
                    long currentEntryOffset = br.BaseStream.Position;
                    var fileEntry = ReadFileEntry(br);

                    if (fileEntry.DataSize == 0 || fileEntry.FileName.StringLength == 0)
                    {
                        continue;
                    }

                    string fileName = br.ReadStringAtOffset(fileEntry.FileName.StringOffset, (int)fileEntry.FileName.StringLength);
                    var resolvedEntry = new FileEntryPack
                    {
                        Offset = (int)fileEntry.DataPointer,
                        Length = fileEntry.DataSize,
                        Name = fileName,
                        CurretnEntryOffset = currentEntryOffset
                    };

                    // Console.WriteLine($"Successfully found: \"{fileName}\" | Size: {fileEntry.FileSize} bytes | Data Offset: 0x{dataAbsolutePos:X}");

                    FileEntries.Add(resolvedEntry);
                }
            }
        }

        private TableDescriptor ReadTableDescriptor(BinaryReader br)
        {
            TableDescriptor descriptor;
            descriptor.FilesCount = br.ReadInt64() >> 34;
            long pointerValueOffset = br.BaseStream.Position;
            long pointerValue = br.ReadInt64() >> 32;

            descriptor.FilesTablePointer = pointerValueOffset + pointerValue;
            return descriptor;
        }

        private FileEntry ReadFileEntry(BinaryReader br)
        {
            FileEntry entry;
            // 16 bytes file name entry
            entry.FileName = BinaryReaderExtensions.ReadTextEntry(br);
            entry.DataSize = br.ReadInt32();
            entry.Flags = br.ReadInt32();

            long dataPointerOffset = br.BaseStream.Position;
            long dataPointerValue = br.ReadInt64() >> 32;
            entry.DataPointer = dataPointerOffset + dataPointerValue;
            return entry;
        }

        public byte[] ExtractFileData(FileEntryPack fileEntry)
        {
            if (string.IsNullOrEmpty(currentFilePath))
            {
                throw new InvalidOperationException("Parser has not opened a file yet.");
            }

            using (var fs = new FileStream(currentFilePath, FileMode.Open, FileAccess.Read))
            using (var br = new BinaryReader(fs))
            {
                fs.Seek(fileEntry.Offset, SeekOrigin.Begin);
                return br.ReadBytes(fileEntry.Length);
            }
        }

        public void ExtractAllFiles(string outputDirectory)
        {
            if (string.IsNullOrEmpty(currentFilePath))
            {
                throw new InvalidOperationException("Parser has not opened a file yet.");
            }
            Directory.CreateDirectory(outputDirectory);
            foreach (var entry in FileEntries)
            {
                byte[] data = ExtractFileData(entry);
                string outputPath = Path.Combine(outputDirectory, entry.Name);
                string extractedFileDir = Path.GetDirectoryName(outputPath);
                if (!Directory.Exists(extractedFileDir))
                {
                    Directory.CreateDirectory(extractedFileDir);
                }
                File.WriteAllBytes(outputPath, data);
                Console.WriteLine($"Extracted file to: {outputPath}");
            }
        }

        public FileEntryPack InjectFileData(string filePathInPack, byte[] newData)
        {
            if (string.IsNullOrEmpty(currentFilePath))
            {
                throw new InvalidOperationException("Parser has not opened a file yet.");
            }

            var entry = FileEntries.FirstOrDefault(e => e.Name.Equals(filePathInPack, StringComparison.OrdinalIgnoreCase));
            if (entry == null)
            {
                throw new FileNotFoundException($"File \"{filePathInPack}\" not found in the pack.");
            }

            int index = FileEntries.IndexOf(entry);

            using (var fs = new FileStream(currentFilePath, FileMode.Open, FileAccess.ReadWrite))
            using (var bw = new BinaryWriter(fs))
            using (var br = new BinaryReader(fs))
            {
                var header = br.ReadStruct<YCDHeader>();

                long entryOnDiskPos = entry.CurretnEntryOffset;

                fs.Seek(fs.Length, SeekOrigin.Begin);
                bw.AlignStream(64);

                long newDataOffset = fs.Length;
                bw.Write(newData);

                fs.Seek(entryOnDiskPos + 16, SeekOrigin.Begin);
                bw.Write((uint)newData.Length);

                long dataPointerOffset = entryOnDiskPos + 16 + 8;
                long relativeDataOffset = newDataOffset - dataPointerOffset;

                long dataPointerVal = (relativeDataOffset << 32) | 0x10;

                fs.Seek(dataPointerOffset, SeekOrigin.Begin);
                bw.Write(dataPointerVal);

                header.AllContainerSize = fs.Length;
                header.AllContainerSize2 = fs.Length;
                fs.Seek(0, SeekOrigin.Begin);
                bw.WriteStruct(header);

                var updatedEntry = new FileEntryPack
                {
                    Name = entry.Name,
                    Offset = (int)newDataOffset,
                    Length = newData.Length,
                    CurretnEntryOffset = entry.CurretnEntryOffset
                };
                FileEntries[index] = updatedEntry;

                return updatedEntry;
            }
        }
    }

}