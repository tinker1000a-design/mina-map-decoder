# Mina 地图解码方法与踩坑记录

最后核对：2026-10-13。成功案例：开场 `extra/introSea` 船甲板。本文记录原文件到拼图的实际流程，不把早期候选当成正确成果。

## 先读这一页

**已经验证的链路：** 原包成员 → `.tlb.yc` 根对象 → 图层与 chunk → u16 瓦片编号 → 669 项 tileInfo → R8 图集中的 8×8 瓦片 → 调色与翻转 → 原世界坐标分层合成 → `.anb.yc` 独立场景素材 → 截图对照。

| 接手时的问题 | 直接答案 |
|---|---|
| 正确场景在哪 | `by-package/level_introSea.pak/levels/extra/introSea.tlb.yc` |
| 正确最终图在哪 | `introSea_reconstructed/opening_deck_6x.png`、`ship_full_4x.png`、`ship_full_plan_4x.png` |
| 先运行什么 | `work/prepare_introsea_inputs.py`，再运行 `work/assemble_introsea_scene.py` |
| 依赖 | Python 标准库；不需要 Pillow、PhotoCraft 或重新跑 Ghidra |
| 本例关键数量 | 26 层、221 个有效 chunk、669 项 tileInfo、1 张静态图集、2613 个实体 |
| 地图瓦片有多大 | 原文件是 8×8；chunk 是 16×16 个瓦片。不能把用户的示例尺寸当实值 |
| 图集在哪 | 解压流 `work/introSea_streams/26_06aef7_008000.bin`，2048×16，R8，32768 字节 |
| 舵、灯、海浪为什么不能只靠瓦片表 | 它们是地图中的 ANB 动画实体，需要另读资源与坐标 |
| 是否用截图像素拼图 | 没有。截图仅用于定位视口、比较颜色与核对结果 |
| 是否用 AI 重画素材 | 当前成品没有。原素材已找到，没有确认的素材缺口 |
| 接下来的范围 | 地图方法复用。战斗、道具、交互机制研究保持冻结 |

### 当前工作区直接复现

PowerShell，使用实际工作区路径；以下是本机路径，不是别的机器的默认安装位置：

```powershell
Set-Location -LiteralPath 'C:\Users\admin\Documents\Codex\2026-10-12\na-h'
python -X utf8 'work\prepare_introsea_inputs.py'
python -X utf8 'work\assemble_introsea_scene.py'
```

第一个命令从已解包的原始 `.yc` 资源重新产生层流、chunk 表、图集流和场景实体索引。第二个命令用这些输入生成三种船图、原生尺寸图、放大图和场景素材 PNG。无需先打开截图，也无需手工补一份实体 JSON。

准备脚本的新默认输出里，`serialized_layer_record_offset` 是真实对象起址；另存 `legacy_shifted_record_offset` 解释旧脚本的 +12 字节偏差。现有组装器沿用已经有效的流文件名与 chunk 表。

## 1. 文件与证据边界

资源目录是 `outputs/Mina the Hollower map assets/by-package/`，按来源包分文件夹，避免同名覆盖。场景基础图来自 `level_introSea.pak`；动画素材主要来自 `global.pak`；默认调色板来自 `global_startup.pak/palettes/global.pal.yc`。

| 输入 | SHA-256 |
|---|---|
| `introSea.tlb.yc` | `a3222000f521d737cc5744df12ee34b5918b3f6533aba8e8c1bbf85d67e6a785` |
| 32768 字节静态图集解压流 | `7eaae25489445b937e9dd9d6c58b5437dd872000ce68336b841fef80a2244a8d` |
| 默认 `global.pal.yc` | `a586d93dd5893ca6ede22afc04dfc94136c935adfcddbdf1dcf2fdfeadb82532` |

这些散列标识当前实物，不能替代游戏版本号。`prepare_introsea_inputs.py` 有本例结构断言；新构建或别的地图不满足时，应检查结构变化，不要删断言强行输出。

已确认：本例表起址、数量、chunk 放置、资源内容，以及截图覆盖区的视觉对应。未确认：全部引擎状态条件、所有属性位的引擎名称、调色板采样的完整运行时代码、任意其他地图的通用兼容性。没有启动游戏验证运行时行为。

## 2. 从 PAK 导出原文件

已有 `by-package/` 和 `asset_manifest.csv` 时，先复用。导出完成不代表地图已解码。

若需要重解包，现有参考实现是 `work/MTH_YCPackUnpacker/source/Parsers/YCDPackParser.cs`，布局参照 `templates/pak_yc.hexpat`。它处理自定义 `.pak.yc` 成员；不要当 ZIP 用，也不要把包解压工具当地图渲染器。

本例包头 `b[0:4] == b'YCD\0'`，内容根地址为 `u64le(b, 0x08)`。根处是 16 字节成员表描述符，成员记录步长 32 字节：

```python
root = u64le(b, 8)
member_count = u32le(b, root + 4) >> 2
table = root + 8 + i32le(b, root + 12)
entry = table + member_index * 32
name_length = u32le(b, entry + 4)
name_at = entry + 8 + i32le(b, entry + 12)
data_size = u32le(b, entry + 16)
data_at = entry + 24 + i32le(b, entry + 28)
raw_member = b[data_at:data_at + data_size]
```

保存原包内相对路径和成员 SHA-256，核对范围是否落在包内。重新导出时对目标路径做范围检查，保留来源包名。此任务只需读取成员，不需回注或修改游戏包。

## 3. 先统一相对指针，别用“碰巧差 4 字节”修补

本例经验证的指针：一个 8 字节槽位，高 32 位是有符号位移，基准是该槽位的低 32 位所在地址。

```python
def relative_qword(b, slot):
    return slot + struct.unpack_from('<i', b, slot + 4)[0]

def vector(b, descriptor):
    count = struct.unpack_from('<I', b, descriptor + 4)[0] >> 2
    data = relative_qword(b, descriptor + 8)
    return count, data
```

如果你手上记的是高 32 位地址 `p`，同一公式就是 `p - 4 + i32le(b,p)`。之前以高字地址为基准再猜 ±4，造成对象与表错位。统一这个公式后，用已知大小和相邻结构检查结果。

16 字节 GameString 在本例中：长度为 `u32(+4)`，数据引用槽位为 `+8`，读到 NUL 截断。不把长度再除以 4；只有上述 vector 的编码计数字使用 `>>2`。

## 4. TLB 根对象：从引用得出表，不扫描出一个像表的区域就认定

读 `root = u64le(b,8)`；本例为 `0x100`。

| 根字段 | 相对根偏移 | 本例表起址 | 实际项数 / 步长 |
|---|---:|---:|---|
| `m_tileLayers` | `0x38` | `0x238` | 26 / `0xa8` |
| `m_entities` | `0x48` | `0x2060` | 2613 / 88 |
| `m_tileInfo` | `0x78` | `0x63324` | 669 / 6 |
| `m_textures` | `0x88` | `0x642d8` | 1 / `0x28` |

本例 tileInfo 表结束地址 `0x63324 + 669×6 = 0x642d2`，下一张纹理描述对齐到 `0x642d8`。这组引用、数量、记录大小和结束位置互相吻合。

根尺寸为 500×500；不是最终裁切图的像素尺寸。各图层有自己的瓦片宽高、世界坐标和稀疏 chunk。

### 类型注册证据怎么读

`work/mina_rea_evidence.json` 保存了 Ghidra/REA 静态证据。根定义 `FUN_1400e0810`、tileInfo `FUN_1400fa460`、纹理 `FUN_1400ef880`、图层 `FUN_1400f00b0` 分别在记录 0、6、7、21。

伪代码中的 `*(member + 0x48) = offset` 是对**刚刚注册的 member** 的赋值，后面的 `local_18 = "下一个字段"` 才开始下一次注册。此前倒着关联，错误地把 tileInfo 读成 +0x68、textures 读成 +0x78。正确值在上表。

证据 ID：根 `ev_03c3e9af271b32d71ef4b1dfb21e4a28b3e6373c21d97735ee9d71cadeeabece`；tileInfo `ev_6d50eebc460525a1a52f7d9b1b467a237bd601dfe22c3eb959f4da715189c2f7`；纹理 `ev_70745854962d04f759d5bf144aa2c7f8365a8e2afec5e8303ad1d17dbd4c7bb5`；图层 `ev_dc1850967e31d9163a297fe19815ff6db0ab7c81f664536f2319c77ad8c14acb`。

## 5. 图层、chunk 和 WFLZ

下面偏移全部相对于**真实图层对象** `obj = layer_base + i×0xa8`：

| 字段 | 偏移 / 读法 |
|---|---|
| 名称 | `+0x10`，GameString |
| paletteNames / usedTextures | `+0x30` / `+0x40`，当前不能由它们宣称已解决全部绑定 |
| chunkStart 描述符 | `+0x50`，用 vector helper |
| 世界位置 x,y | `+0x68`，两个 little-endian float32 |
| 宽高，单位瓦片 | `+0x80,+0x84`，u32 |
| depth | `+0x8c`，float32 |
| startVisible/startEnabled 等 | `+0x94..+0x97`，当前不能替代运行时事件条件 |
| tileData 的 WFLZ 地址 | `relative_qword(b,obj+0xa0)`，先核对 magic |

旧层提取器的 `obj=0x244+i×0xa8` 实际晚了 12 字节。它在 chunk 与 tileData 指针位置恰好读对，但用同一基址读 position 就错了。不要只修表面上的零坐标。当前准备脚本统一用真实基址。

chunk 的边长是 16 个瓦片。密集槽表尺寸 `ceil(width/16)×ceil(height/16)`。每槽是 u32 的 tile-cell 起点；`0xffffffff` 表示缺块，其余应为 256 的倍数。chunk 内部按行读取：

```python
chunk_x, chunk_y = slot % chunk_columns, slot // chunk_columns
cell_index = chunk_start + local_y * 16 + local_x
raw = u16le(decoded, cell_index * 2)
tile_x, tile_y = chunk_x * 16 + local_x, chunk_y * 16 + local_y
```

先跳过 `tile_x >= width` 或 `tile_y >= height` 的末块填充。否则会把未使用的高值当成有意义的素材/flags，浪费排错时间。每块解压是 256×2=512 字节。

WFLZ 解码：magic 后 +4/+8 是 compressedSize/rawSize；第一个 `<HBB>` token 从 **marker+12** 开始。`distance:u16,length:u8,literals:u8`。length 非零时，从已输出内容回拷 `length+4` 字节，允许重叠；然后追加 literals 个源字节。length 和 literals 同时为零终止。逐段检查引用合法性，并要求最终大小等于 rawSize。不要跳过所谓“完整 16 字节头”而漏掉首 token。

两个数据用途不可混淆：图层流是 u16 索引；图集流是 R8 像素索引。解压长度吻合是必要检查，不足以证明瓦片寻址正确。

## 6. 真正的瓦片寻址与颜色

tileInfo 每项 `<HHH>`：textureIndex、textureTileIndex、collisionType。本例 textureIndex 为 0 或 0xffff，textureTileIndex 为 0..389。

```python
if raw == 0:                     # 空位
    skip()
index = (raw & 0x1fff) - 1       # 一基 tile ID，不是直接用 raw
texture_index, atlas_tile, collision = tile_info[index]
if texture_index == 0xffff:
    skip_static_texture()        # 不得把 65535 当 atlas 下标；独立动画实体另处理
```

当前像素变换实现：`0x4000` 翻转 x、`0x8000` 翻转 y，随后 `0x2000` 交换采样 x/y。必须保留操作次序。低 8 位不够：669 项不能用 256 项索引覆盖。高字节也不是统一的 tile ID。

本例唯一静态纹理 2048×16，tile 8×8，256 列×2 行。图集 tile 地址：

```python
atlas_x = (atlas_tile % 256) * 8
atlas_y = (atlas_tile // 256) * 8
palette_index = texture[(atlas_y + source_y) * 2048 + atlas_x + source_x]
```

palette_index=0 丢弃；当前彩色采样为 `P[0xe8 + palette_index*4 : 0xec + palette_index*4]`。这是在当前原资源和截图 RGB 上核对过的对齐，**不是已证明的所有 `.pal.yc` 通用格式常量**。此前 +0xf0 解码产生错误的荧绿/深蓝；同一个 palette 错当两级重映射也不成立。不要为了符合旧笔记而改回不匹配的颜色。

做图集接触表再看：原船舷、木板、桶和水面都能辨认，说明像素数据解释有依据；仅能辨认接触表仍不能证明地图放置。当前 renderer 是针对本例的单纹理、二值透明合成；非单位缩放、半透明混合或多纹理的新场景需适配。

## 7. 实体与 ANB：把舵、桅杆、灯和海面补回

实体对象步长 88，表 `[0x2060,0x3a298)`。记录 +0 是 props vector；+0x10 是 xy；+0x18 是 scale xy；本例 +0x40 的 u32 对应图层编号。

props 的每项 24 字节，其值指针槽在 +0x10。当前准备脚本仅提取合法可打印 ASCII 引用，得到资源路径、动画名和部分标签；**不是完整属性类型解码器**。不把选出的字符串表当全部关卡逻辑。

实体 2504：`helm.anb.yc`，位置 `(1840,2568)`；动画帧尺寸20×15，anchor `(-2,-15)`，因此未镜像时绘制左上角 `(1838,2553)`。这正是截图中的船舵，不是看到截图后手摆物件。

`MainAreaSceneCam` 实体 2569 的静态位置是 `(1984,2448)`。这个标记本身不能当作用户截图当前相机左上角；真正截图裁切由画面对应关系求得。

ANB 也从头部 +8 读取 root，不能固定成0x100：本例 helm/mast 是0x100，shipLamp 是0xc0。

| ANB 数据 | root-relative vector | 步长 | 当前关键内容 |
|---|---:|---:|---|
| 动画 clip 表 | `+0x28` | 56 | 名称、帧引用 |
| frame 表 | `+0x38` | 56 | texture index、元信息引用 |
| texture 表 | `+0x48` | 32 | width/height、WFLZ 引用 |

clip 名称结构在 record+8；其帧列表 vector 在 +24，列表记录步长24，首 u32 为 frame ID。frame 首 u32 是 texture ID，+24 的 vector 指向元信息；元信息前16字节是 `<IIff>` 的 width、height、anchor x、anchor y。texture 的 width/height 在 +0/+4，WFLZ 地址为 `relative_qword(b,texture_record+24)`。

选择地图属性中的动画名，取该 clip 第一帧。优先使用实体提供的 palette override，否则使用默认 global palette。镜像会同时影响像素与 anchor：

```python
left = x + (anchor_x if scale_x >= 0 else -anchor_x - image_width)
top  = y + (anchor_y if scale_y >= 0 else -anchor_y - image_height)
```

当前脚本只处理 scale 的正负符号；非 ±1 缩放不能按本例直接套。保存的 recovered_sprites 已应用首次遇到实体的镜像，复用为未变换素材时应从 ANB 重新解码，而不是再次盲目翻转 PNG。

按图层依次合成静态瓦片与绑定到该层的动画实体。海面是独立动画实体；只画静态图集会得到错误的水面观感。不要把所有实体最后铺在船体上。

现有 assembler 的“无匹配动画时回退第一个 clip”仅是场景专用实现边界；扩展到其他地图前改成明确报告未匹配项，避免静默错图。同样，固定像素范围的实体筛选和整帧 texture 绘制只适用于当前输入。

## 8. 显隐、裁切与截图核对

原图包含常态、闪烁、受击、毁坏等多层。本例可见层组合由截图和层名核对选出，不是已经重建完整条件表达式或事件系统。`assembly_manifest.json` 保存实际资源、frame、实体和坐标；`ship_full_plan` 另外隐藏 FG 层，用于看布局，不能叫“所有前景都显示的截图”。

图层 world y 向下的组合与截图一致。曾把整个地图旋转并缩放到截图尺寸，这种方法不能验证相机画面。

这张1920×1080截图实际按7.5倍缩放到256×144原生视口。采样原像素中心 `floor((x+0.5)*7.5)`，寻找固定船壳/栏杆图案的位置。对齐结果是完整地图画布 `(148,919)`，画布世界原点 `(1616,1568)`，因此截图左上角为 `(1764,2487)`。导出甲板范围256×128，裁去底部 HUD。

核对层次：先对照形状与方向，再对照固定素材像素，再比较动画帧。不要用 NPC、HUD 或随机波浪作为唯一锚点。该截图只是校验输入，没有进入最终像素合成数据源。

810 个船尾样本全匹配。进一步比较 x=18..150、y=0..127，排除人物矩形 `(59,32,78,54)`、`(115,18,132,43)`、`(87,50,115,78)`、`(118,53,142,75)`，14,727/14,869 个 RGB 像素一致，99.045%。范围是船景的所选区域；不能宣传整图或任意场景99%已复现。动画按首帧，因此时间相位并非截图的实时帧。

## 9. 踩坑速查

| 症状 / 失败做法 | 原因与正确处理 |
|---|---|
| 拼得像船但甲板全是重复粉色横条 | tileInfo 起址在表中间且错开2字节。由 root 引用定位0x63324，而不是扫描到0x63cd4就使用 |
| textureIndex 看似0..389、另一个字段0..35 | 这是错位后把 atlas index 当 texture index、把 collision 当 tile index。正确纹理索引仅0/FFFF |
| 只读 tile-data 低字节 | 丢失>255的真实索引和属性位。先mask，再减1 |
| 把高字节当所有层的瓦片编号 | OCEAN 高字节全零已经反证；区分ID与顶端属性位 |
| 图层坐标全零，靠全图旋转“修正” | obj基址晚12字节。改基址后按世界位置叠层，用真实视口裁切 |
| raw stream 出现类似地址的高值 | 先排除末块宽高外的填充数据，再判断索引异常；不要凭一段填充认定解压失败 |
| 海面像网状静态格子 | 忽略了water/roughWater等ANB实体。按各自层次补动画帧 |
| 船舵/桅杆/灯找不到 | 它们不是仅靠静态tileInfo就能画出的块；读ANB clip、anchor和实体位置 |
| 解压数量正确但画面错 | 数量校验只证明长度。还需查表地址、字段顺序、索引基数、透明索引和坐标 |
| 荧绿、紫绿或黑白素材被当原色 | R8是索引数据；调色板/采样对齐未处理。接触表与截图RGB一起核对 |
| 把一个palette两次重映射 | shader里存在双palette不代表能用同一资源代替两张表；没确认绑定前不这样做 |
| 首token读错、回拷重复短缺 | WFLZ token始于+12，length非零加4；重叠引用逐字节从输出回读 |
| 长时间反复等Ghidra搜索 | 取消会丢弃临时数据库并重新导入。复用现有REA证据，再用格式结构约束排错，不重复同一挂起请求 |
| 本机Python缺Pillow导致停摆 | 原图像可由标准库zlib写PNG；不必为本例安装新依赖 |
| 自由生成一张“看起来对”的船图 | 无法证明游戏里实际存在。先恢复地图和资产关系；生成补片只能对应已确认的缺口 |

旧 `render_introsea_tile_candidate*.py`、高字节/反字段/F0 实验、旋转的候选图、weaponGet概念图和自由重绘稿，只是历史诊断/失败记录。它们不能覆盖当前正确输出，也不能据其论证已经复现别的关卡。

## 10. 复用与停止条件

本例已经结束，无需为了文档再展开战斗机制或重做安装。成本最低的排错顺序：定位表引用 → 用数量/步长/边界做不变量检查 → 看小型图集接触表 → 拼一小块有特征的场景 → 对照截图 → 扩大范围。

用于其他地图时沿用结构公式，重新求 root、数组位置、数量、texture format、调色与显隐条件；绝不能照抄本例绝对偏移、669项、单纹理及排除层名单。发现多纹理/RGBA/不同anchor/非单位缩放，先调整对应环节再扩大范围。

若没有新证据，不重复同一解码猜测或长等待。按用户时间/额度约束停在具体未知项，保存当前输入、证据、失败假设和下一次最小验证问题。不能通过移除边界检查、自由重画或不披露fallback制造“完成”。

### 已做的复现检查

新准备脚本在独立 `work/introSea_method_check/` 输出。26个层流与原成功输入逐字节一致；1个图集流逐字节一致；2561条动画场景实体索引与成功版本JSON完全相等；共221个chunk的结构断言通过。当前输出图未被这次检查覆盖。

### 文件入口

- `work/prepare_introsea_inputs.py`：原YC输入到可复现中间文件，替代未保存的临时实体扫描命令。
- `work/render_introsea_corrected.py`：瓦片拼接。仍有场景专用常量，修改其他地图前先读本文件的边界说明。
- `work/assemble_introsea_scene.py`：ANB解码、按层补实体、三种视图、素材导出。
- `work/mina_rea_evidence.json`：类型注册等静态证据，不等于实时连接或运行时验证。
- `introSea_reconstructed/assembly_manifest.json`、`screenshot_alignment.json`：素材放置和截图核对证据。
- `introSea_reconstructed/tileInfo.csv`：当前原表索引导出；`layer_index_corrected.json`：当前位置与深度。

已安装技能 `$mina-map-decoder` 的参考文档是本文同内容快照，脚本为上述成功实现的副本；不打包游戏原素材。重新复现应提供原资源目录，并沿用用户已确认的任务范围。

### 技能独立使用

技能安装于 `C:\Users\admin\.codex\skills\mina-map-decoder`。可在新对话使用 `$mina-map-decoder`，或直接执行下列命令；`--out` 必须是尚不存在的新目录：

```powershell
python -X utf8 'C:\Users\admin\.codex\skills\mina-map-decoder\scripts\rebuild_introsea.py' --assets 'C:\Users\admin\Documents\Codex\2026-10-12\na-h\outputs\Mina the Hollower map assets\by-package' --out 'C:\Users\admin\Documents\Codex\2026-10-12\na-h\work\my_introSea_rebuild'
```

技能副本把输入/中间文件/输出路径改成可配置参数，并在原资源目录之外写入；未知clip不再静默回退，异常瓦片与缺失素材会报告失败。导出的镜像sprite文件加了flipX/flipY前缀。它不读取旧成品图或截图来生成像素。

技能已通过skill-creator的结构检查。其脚本在独立 `work/mina_skill_rebuild_check/` 重建出六张原生/放大PNG，文件SHA-256与原交付六张图全部相同；逐项结果见 `introSea_reconstructed/method_verification.json`。无需再次重建证明同一结果，只有后续修改或失败才需要重新验证。
