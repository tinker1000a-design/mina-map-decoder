from pathlib import Path
import os
ASSET_ROOT=Path(os.environ.get('MINA_MAP_ASSET_ROOT','outputs/Mina the Hollower map assets/by-package'))
WORK_ROOT=Path(os.environ.get('MINA_MAP_WORK_ROOT','work'))
import struct,csv,json,zlib
B=(ASSET_ROOT/'level_introSea.pak/levels/extra/introSea.tlb.yc').read_bytes();P=(ASSET_ROOT/'global_startup.pak/palettes/global.pal.yc').read_bytes();T=(WORK_ROOT/'introSea_streams/26_06aef7_008000.bin').read_bytes()
O=(WORK_ROOT/'introSea_corrected');O.mkdir(exist_ok=True)
def png(path,w,h,data):
 def c(t,d):return struct.pack('>I',len(d))+t+d+struct.pack('>I',zlib.crc32(t+d)&0xffffffff)
 rows=b''.join(b'\0'+data[y*w*4:(y+1)*w*4] for y in range(h))
 path.write_bytes(b'\x89PNG\r\n\x1a\n'+c(b'IHDR',struct.pack('>IIBBBBB',w,h,8,6,0,0,0))+c(b'IDAT',zlib.compress(rows))+c(b'IEND',b''))
def composite(dst,dw,dh,src,sw,sh,dx,dy):
 for y in range(sh):
  if not 0<=y+dy<dh:continue
  for x in range(sw):
   if not 0<=x+dx<dw:continue
   q=(y*sw+x)*4
   if src[q+3]:
    z=((y+dy)*dw+x+dx)*4;dst[z:z+4]=src[q:q+4]
s=0x184+struct.unpack_from('<i',B,0x184)[0]-4;n=struct.unpack_from('<I',B,0x17c)[0]//4;infos=[struct.unpack_from('<3H',B,s+i*6) for i in range(n)]
layers=list(csv.DictReader(open(WORK_ROOT/'introSea_layers_verified/layer_stream_index.csv',encoding='utf-8-sig')));placements=json.loads((WORK_ROOT/'introSea_layers_verified/chunk_placement.json').read_text())
exclude={'OCEAN','GROUND_FLASH3','GROUND_HITSHIP','EXTRA_COLLISION','GROUND_FLASH1','DETAIL_HITSHIP','DETAIL_FLASH1__!FLASH3','DETAIL_FLASH1','DETAIL_FLASH1_!FLASH2','GROUND_FLASH2_!BATTLE','FG_FLASH1_!FLASH2'}
assembled=[]
for L in layers:
 i=int(L['layer_index']);o=0x244+i*0xa8;w,h=json.loads(L['layer_dims_tiles']);x,y=struct.unpack_from('<ff',B,o+0x5c);data=bytearray(w*h*64*4);values=struct.unpack('<'+'H'*(int(L['decoded_bytes'])//2),Path(L['decoded_file']).read_bytes());invalid=drawn=0
 for C in (c for c in placements if c['layer_index']==i):
  for cy in range(16):
   for cx in range(16):
    tx=C['chunk_x']*16+cx;ty=C['chunk_y']*16+cy
    if tx>=w or ty>=h:continue
    raw=values[C['tile_data_cell_offset']+cy*16+cx];idx=(raw&0x1fff)-1
    if raw==0:continue
    if not 0<=idx<n:invalid+=1;continue
    tex,ti,col=infos[idx]
    if tex==65535:continue
    if tex!=0 or ti>=512:invalid+=1;continue
    for py in range(8):
     for px in range(8):
      sx=7-px if raw&0x4000 else px;sy=7-py if raw&0x8000 else py
      if raw&0x2000:sx,sy=sy,sx
      v=T[((ti//256)*8+sy)*2048+(ti%256)*8+sx]
      if v:
       z=((ty*8+py)*w*8+tx*8+px)*4;data[z:z+4]=P[0xe8+v*4:0xec+v*4]
    drawn+=1
 if invalid:raise ValueError(f'{L["layer_name"]}: {invalid} unresolved tile cells')
 png(O/f'{i:02d}_{L["layer_name"]}.png',w*8,h*8,data);assembled.append((L['layer_name'],int(x),int(y),w*8,h*8,data));print(i,L['layer_name'],'drawn',drawn,'invalid',invalid)
for orient in ['down','up']:
 boxes=[(nm,x,y if orient=='down' else -y-h,w,h,d) for nm,x,y,w,h,d in assembled if nm not in exclude];minx=min(b[1] for b in boxes);miny=min(b[2] for b in boxes);maxx=max(b[1]+b[3] for b in boxes);maxy=max(b[2]+b[4] for b in boxes);cw=maxx-minx;ch=maxy-miny;canvas=bytearray(bytes([10,30,40,255])*cw*ch)
 for nm,x,y,w,h,d in boxes:composite(canvas,cw,ch,d,w,h,x-minx,y-miny)
 png(O/f'map_{orient}.png',cw,ch,canvas);(O/f'map_{orient}.rgba').write_bytes(canvas);print(orient,'bounds',minx,miny,maxx,maxy)
json.dump({'tileInfo_start':hex(s),'tileInfo_count':n,'flag_decode':'provisional top 3 bit transforms','palette_offset':'0xe8 provisional'},open(O/'decode_progress.json','w'),indent=2)

