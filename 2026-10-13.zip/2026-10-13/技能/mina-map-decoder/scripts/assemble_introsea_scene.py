from pathlib import Path
import os
import struct,json,collections
import render_introsea_corrected as R
OUT=Path(os.environ.get('MINA_MAP_OUTPUT_DIR','outputs/Mina the Hollower map assets/introSea_reconstructed'));OUT.mkdir(exist_ok=True)
ASSETS=(R.ASSET_ROOT/'global.pak');CACHE={};SPRITEOUT=OUT/'recovered_sprites';SPRITEOUT.mkdir(exist_ok=True);SAVED=set()
def vec(b,o):return struct.unpack_from('<I',b,o+4)[0]//4,o+8+struct.unpack_from('<i',b,o+12)[0]
def wflz(b,o):
 comp,raw=struct.unpack_from('<II',b,o+4);i=o+12;out=bytearray()
 while True:
  d,l,p=struct.unpack_from('<HBB',b,i);i+=4
  if not l and not p:break
  if l:
   for _ in range(l+4):out.append(out[-d])
  out+=b[i:i+p];i+=p
 assert len(out)==raw
 return out

def anb(path):
 if path in CACHE:return CACHE[path]
 b=(ASSETS/path).read_bytes();root=struct.unpack_from('<Q',b,8)[0];clips={};frames=[];textures=[]
 n,p=vec(b,root+0x28)
 for i in range(n):
  q=p+i*56;ln=struct.unpack_from('<I',b,q+12)[0];sp=q+16+struct.unpack_from('<i',b,q+20)[0];nm=b[sp:sp+ln].split(b'\0')[0].decode();nc,np=vec(b,q+24);clips[nm]=[struct.unpack_from('<I',b,np+j*24)[0] for j in range(nc)]
 n,p=vec(b,root+0x38)
 for i in range(n):
  q=p+i*56;_,mp=vec(b,q+24);w,h,dx,dy=struct.unpack_from('<IIff',b,mp);frames.append((struct.unpack_from('<I',b,q)[0],w,h,dx,dy))
 n,p=vec(b,root+0x48)
 for i in range(n):
  q=p+i*32;w,h=struct.unpack_from('<II',b,q);dp=q+24+struct.unpack_from('<i',b,q+28)[0];raw=wflz(b,dp);assert len(raw)==w*h;textures.append((w,h,raw))
 CACHE[path]=(clips,frames,textures);return CACHE[path]

E=json.load(open(R.WORK_ROOT/'introSea_corrected/animated_scenery_entities.json'));layers=R.assembled
# OCEAN is animated and replaces OCEANSTATIC; omit collision and alternate damage/flash states.
excluded=R.exclude-{'OCEAN'}
views={'ship_full':(1712,2152,304,544),'ship_full_plan':(1712,2152,304,544),'opening_deck':(1764,2487,256,128)}
placements=[];missing=[]
for label,(vx,vy,vw,vh) in views.items():
 canvas=bytearray(bytes([13,32,48,255])*vw*vh)
 for li,(lname,lx,ly,lw,lh,ld) in enumerate(layers):
  if lname in excluded or label=='ship_full_plan' and lname.startswith('FG_'):continue
  R.composite(canvas,vw,vh,ld,lw,lh,lx-vx,ly-vy)
  for e in (e for e in E if e['tail'][2]==li):
   ex,ey=e['position']
   if not vx-96<=ex<=vx+vw+96 or not vy-128<=ey<=vy+vh+128:continue
   try:clips,frames,textures=anb(e['asset'])
   except (FileNotFoundError,AssertionError,struct.error) as er:missing.append([e['index'],e['asset'],type(er).__name__]);continue
   clip=next((s for s in e['strings'] if s in clips),None)
   if clip is None or not clips[clip]:missing.append([e['index'],e['asset'],'no clip']);continue
   fi=clips[clip][0];ti,fw,fh,dx,dy=frames[fi];tw,th,raw=textures[ti]
   palette_path=next((s for s in e['strings'] if s.endswith('.pal.yc')),None);pb=(ASSETS/palette_path).read_bytes() if palette_path else R.P
   rgba=bytearray(tw*th*4)
   sx,sy=e['scale']
   for yy in range(th):
    for xx in range(tw):
     px=tw-1-xx if sx<0 else xx;py=th-1-yy if sy<0 else yy;v=raw[py*tw+px]
     if v:rgba[(yy*tw+xx)*4:(yy*tw+xx+1)*4]=pb[0xe8+v*4:0xec+v*4]
   asset_key=('flipX_' if sx<0 else '')+('flipY_' if sy<0 else '')+Path(e['asset']).name.replace('.anb.yc','')+'_'+clip+'_'+(Path(palette_path).stem if palette_path else 'global')
   if asset_key not in SAVED:R.png(SPRITEOUT/(asset_key+'.png'),tw,th,rgba);SAVED.add(asset_key)
   ox=int(ex+(dx if sx>=0 else -dx-tw));oy=int(ey+(dy if sy>=0 else -dy-th))
   R.composite(canvas,vw,vh,rgba,tw,th,ox-vx,oy-vy)
   if ox+tw>vx and ox<vx+vw and oy+th>vy and oy<vy+vh:placements.append({'view':label,'entity':e['index'],'layer':li,'asset':e['asset'],'clip':clip,'frame':fi,'worldTopLeft':[ox,oy],'dimensions':[tw,th]})
 R.png(OUT/f'{label}_native.png',vw,vh,canvas);(OUT/f'{label}_native.rgba').write_bytes(canvas)
 # Exact integer nearest-neighbour enlargement; preserve palette and pixel edges.
 factor=4 if label.startswith('ship_full') else 6
 rows=[]
 for y in range(vh):
  row=b''.join(canvas[(y*vw+x)*4:(y*vw+x+1)*4]*factor for x in range(vw));rows.extend([row]*factor)
 R.png(OUT/f'{label}_{factor}x.png',vw*factor,vh*factor,b''.join(rows))
if missing:raise RuntimeError(f'Unresolved scenery references: {missing[:8]}')
json.dump({'views':views,'spritePlacements':placements,'missing':missing,'animationFrame':'first frame of the map-specified clip; no live timing','source':'original game map, atlas, ANB sprites and palette resources'},open(OUT/'assembly_manifest.json','w'),indent=2)
print('OUTPUT',OUT.resolve(),'sprites',len(placements),'missing',len(missing));print(collections.Counter(p['asset'].split('/')[-1] for p in placements));print(missing[:8])


