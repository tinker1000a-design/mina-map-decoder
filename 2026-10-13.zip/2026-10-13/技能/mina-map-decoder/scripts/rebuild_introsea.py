"""Rebuild the verified introSea ship from original unpacked resources.

Inputs are read-only. The output must be a new directory. All intermediates
are created under output/_work, so no historical workspace files are needed.
"""
from pathlib import Path
import argparse
import os
import subprocess
import sys


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--assets', type=Path, required=True, help='Original by-package directory')
    parser.add_argument('--out', type=Path, required=True, help='New output directory')
    args = parser.parse_args()
    assets, output = args.assets.resolve(), args.out.resolve()
    map_file = assets / 'level_introSea.pak/levels/extra/introSea.tlb.yc'
    for required in (map_file, assets / 'global_startup.pak/palettes/global.pal.yc',
                     assets / 'global.pak/levels/tilesets/introBeach/animTiles/helm.anb.yc'):
        if not required.is_file():
            parser.error(f'Missing original input: {required}')
    if output.exists():
        parser.error(f'Output already exists; choose a new directory: {output}')
    if output == assets or assets in output.parents:
        parser.error('Output must not be inside the original asset directory')
    output.mkdir(parents=True)
    scripts = Path(__file__).resolve().parent
    working = output / '_work'
    environment = os.environ.copy()
    environment.update({
        'MINA_MAP_ASSET_ROOT': str(assets),
        'MINA_MAP_WORK_ROOT': str(working),
        'MINA_MAP_OUTPUT_DIR': str(output),
        'PYTHONIOENCODING': 'utf-8',
    })
    subprocess.run([sys.executable, '-X', 'utf8', str(scripts / 'prepare_introsea_inputs.py'),
                    '--map', str(map_file), '--work-root', str(working)],
                   cwd=output, env=environment, check=True)
    subprocess.run([sys.executable, '-X', 'utf8', str(scripts / 'assemble_introsea_scene.py')],
                   cwd=output, env=environment, check=True)
    print(f'Reconstruction complete: {output}')


if __name__ == '__main__':
    main()
