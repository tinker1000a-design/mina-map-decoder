---
name: mina-map-decoder
description: Decode and reconstruct Mina the Hollower maps from original PAK/YC resources, including TLB tile layers, WFLZ streams, R8 atlases, palettes and ANB scenery sprites. Use for asset extraction, faithful map assembly or explaining this decoding workflow; the bundled executable path is verified only for the introSea opening ship.
---

# Mina Map Decoder

Reconstruct the requested scene from original map coordinates and asset references. Use a screenshot to locate and verify the scene. Generate replacement art only for a demonstrated asset gap, with its extent recorded.

## Start with the existing evidence

- Find the user's actual resource/workspace directory. Reuse matching unpacked members and successful outputs rather than reinstalling REA or redoing the investigation.
- Read [the field formulas, verified case and pitfalls](references/format-and-pitfalls.md). Its first page is the quick handoff; read the detailed section for the component being changed.
- Preserve the user's requested scene and any pauses or token/time constraints. This skill does not initiate combat or unrelated feature research.

## Verified introSea reconstruction

The helper accepts the **by-package directory**, containing `level_introSea.pak`, `global.pak` and `global_startup.pak`. It embeds no game resources and requires only Python's standard library.

```powershell
python -X utf8 '<skill-directory>\scripts\rebuild_introsea.py' --assets '<by-package-directory>' --out '<new-output-directory>'
```

Choose a new output directory. The helper rejects existing output paths, regenerates intermediate inputs there and never writes to the supplied assets. It parses the original `.yc` files; it does not need a screenshot, the old entity JSON, Pillow, PhotoCraft, a running game or a live Ghidra session.

Expected admission checks: 26 layers, 221 occupied chunks, 669 tileInfo entries, one 2048×16 R8 atlas, 2613 entities. The first-frame static output includes the screenshot-aligned deck, full ship and a layout view with foreground obstruction hidden. Report that distinction and do not claim live animation timing or complete runtime state reproduction.

## Essential invariants

- Read root from header `u64(+8)` and derive arrays through references. Absolute introSea offsets are evidence for this case, not offsets for every map.
- Relative qword: signed high-word displacement is based at the low-word address. Vector count is high-word `>>2`; string length is not divided by four.
- Correct layer base is `0x238`, not the old `0x244`. Correct tileInfo base/count is `0x63324`/669, not the misaligned `0x63cd4`/256.
- Read tile-data as u16; skip chunk padding outside layer width/height. Zero is empty; current indexing is `(raw & 0x1fff)-1`. Texture index and atlas tile index are separate fields.
- ANB scenery entities supply the helm, lamps, masts and animated sea. Respect their layer, clip, anchor, palette override and mirror. Do not append every sprite on top of the ship.
- Current `0xe8` palette sampling and top-three-bit transforms match the reference scene's pixels. Their complete engine semantics and generality remain unconfirmed.

## Other scenes or versions

The bundled preparer deliberately asserts the verified introSea structure. If the input fails admission, inspect the specific root/vector/format change and adapt a copy of the parser using the reference. Do not remove checks, copy scene offsets, reuse the normal-state exclusion list or silently choose an arbitrary animation to obtain a plausible image.

The renderer is intentionally limited: one static R8 texture, palette samples with binary transparency, scene-specific visibility, sign-only sprite scaling and first-frame whole-texture sprite rendering. Handle multiple textures, RGBA formats, alpha blending, frame subrectangles, non-unit scales or different state conditions when the new input requires them.

For a new investigation, use retained native type evidence before expensive searches. A cancelled Ghidra request may discard its ephemeral analysis database. Do not keep repeating a hanging query or the same failed hypothesis without a changed input or new evidence; report the concrete unknown when the user's budget requires stopping.

## Delivery

Show the actual assembled image and provide native/nearest-neighbour enlarged PNGs, source and placement manifest, comparison boundaries and unresolved rendering assumptions. Keep original-resource assembly distinct from generated patches and from runtime verification. In this verified case, successful independent reconstruction should reproduce the existing PNG hashes; this checks reproducibility, not engine-wide correctness.
