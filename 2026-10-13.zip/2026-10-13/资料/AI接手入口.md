# Mina 地图任务：AI 接手入口

先读 [Mina地图解码方法与踩坑记录.md](Mina地图解码方法与踩坑记录.md) 的“先读这一页”，需要改解析时再查对应章节。无需重新遍历对话或重装REA。

当前真实开场船已经拼好；输出在 `introSea_reconstructed/`。用户需要依据真实地图研究关卡设计。战斗、道具和交互机制研究冻结，不自动接续。

必须保留的纠正：tileInfo 是从root引用得到的0x63324/669项；旧0x63cd4/256项方案错位。真实图层基址0x238，旧0x244晚12字节。瓦片8×8；tile-data按u16读取，0空位，其余mask高位后减1查表。舵、桅杆、灯和海浪需要ANB实体，位置来自地图。

原YC文件已按来源包导出到 `by-package/`。复现顺序：

```powershell
Set-Location -LiteralPath 'C:\Users\admin\Documents\Codex\2026-10-12\na-h'
python -X utf8 'work\prepare_introsea_inputs.py'
python -X utf8 'work\assemble_introsea_scene.py'
```

这两个命令只用Python标准库。准备脚本会生成此前临时命令产生的全部必要中间输入。不要再使用旧灰度解释、低字节/高字节/反字段候选、整图旋转或自由重绘稿。

证据范围：810个船尾样本全部匹配；所选船景区域排除人物后14727/14869像素相同。海面用动画首帧，不含人物/HUD；布局版隐藏FG遮挡层。并未启动游戏验证所有运行时条件；+0xe8调色采样与高三位变换是本场景像素核对过的实现，不是已证明的全引擎通用规则。

新准备脚本已经在独立目录复现，与成功输入的26层流、1个图集流及2561条动画实体索引完全一致。其他地图必须重新解析指针/数量和资源绑定，不能照抄本例常量。

技能入口为 `C:\Users\admin\.codex\skills\mina-map-decoder\SKILL.md`，可用 `$mina-map-decoder` 调用。若受时间/额度限制且没有新证据，记录具体缺口后停止重复推理。

技能带有独立 `scripts/rebuild_introsea.py --assets <by-package目录> --out <新输出目录>` 入口，输入仅需原解包YC文件。技能副本独立生成的六张PNG与交付逐字节相同；它不需要当前对话、旧中间JSON或成品图。检查记录在 `introSea_reconstructed/method_verification.json`。
